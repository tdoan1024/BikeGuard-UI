#include "MyForm.h"
#include "MapForm.h"


using namespace System;
using namespace System::Windows::Forms;


[STAThread]
void main(array<String^>^ args)
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);

	BikeGuardUI1::MyForm form;
	Application::Run(%form);
	
}


