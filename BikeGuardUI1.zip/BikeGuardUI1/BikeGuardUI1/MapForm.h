#pragma once

#include <string>
#include <windows.h>
#include <stdio.h>
#include <stdio.h>
#include <iostream>

extern std::string CoordString;


namespace BikeGuardUI1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	
	

	/// <summary>
	/// Summary for MapForm
	/// </summary>
	public ref class MapForm : public System::Windows::Forms::Form
	{
	public:
		MapForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}


	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MapForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::WebBrowser^  webBrowser1;
	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(MapForm::typeid));
			this->webBrowser1 = (gcnew System::Windows::Forms::WebBrowser());
			this->SuspendLayout();
			// 
			// webBrowser1
			// 
			this->webBrowser1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->webBrowser1->Location = System::Drawing::Point(0, 0);
			this->webBrowser1->MinimumSize = System::Drawing::Size(20, 20);
			this->webBrowser1->Name = L"webBrowser1";
			this->webBrowser1->Size = System::Drawing::Size(472, 421);
			this->webBrowser1->TabIndex = 0;
			/////////////////////////////////////////////////////////////////////////////
			
			//Convert to String^, and add to url
			String^ url = gcnew String(CoordString.c_str());
			String^ mainURL = "https://www.google.com/maps/search/" + url;
			
			//Console output
			std::cout << "Current GPS coordinates displayed: " << CoordString << std::endl;
			std::cout << "Connecting to https://www.google.com/maps/search/" << CoordString << std::endl;

			//Initialize browser URL
			this->webBrowser1->Url = (gcnew Uri(mainURL, UriKind::Absolute));

			/////////////////////////////////////////////////////////////////////////////
			this->webBrowser1->DocumentCompleted += gcnew System::Windows::Forms::WebBrowserDocumentCompletedEventHandler(this, &MapForm::webBrowser1_DocumentCompleted);
			// 
			// MapForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(14, 29);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(472, 421);
			this->Controls->Add(this->webBrowser1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->MinimumSize = System::Drawing::Size(500, 500);
			this->Name = L"MapForm";
			this->Text = L"BikeGuard Map";
			this->WindowState = System::Windows::Forms::FormWindowState::Maximized;
			this->Load += gcnew System::EventHandler(this, &MapForm::MapForm_Load);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void MapForm_Load(System::Object^  sender, System::EventArgs^  e) {

	}
	private: System::Void webBrowser1_DocumentCompleted(System::Object^  sender, System::Windows::Forms::WebBrowserDocumentCompletedEventArgs^  e) {
	}
	};
}
